import json
def stimulus_gen() -> list[dict]:
    scenarios = [
        {
            "scenario": "AllZerosInput",
            "input variable": [{"x": "0000"}]
        },
        {
            "scenario": "TopRowTransition",
            "input variable": [
                {"x": "0000"},
                {"x": "0001"},
                {"x": "0011"},
                {"x": "0010"}
            ]
        },
        {
            "scenario": "BottomRowSweep",
            "input variable": [
                {"x": "1100"},
                {"x": "1101"},
                {"x": "1111"},
                {"x": "1110"}
            ]
        },
        {
            "scenario": "LeftColumnTransition",
            "input variable": [
                {"x": "0000"},
                {"x": "0100"},
                {"x": "1100"},
                {"x": "1000"}
            ]
        },
        {
            "scenario": "RightColumnSweep",
            "input variable": [
                {"x": "0010"},
                {"x": "0110"},
                {"x": "1110"},
                {"x": "1010"}
            ]
        },
        {
            "scenario": "AlternatingBits",
            "input variable": [
                {"x": "0101"},
                {"x": "1010"}
            ]
        },
        {
            "scenario": "MaximumValue",
            "input variable": [{"x": "1111"}]
        },
        {
            "scenario": "OneHotPatterns",
            "input variable": [
                {"x": "0001"},
                {"x": "0010"},
                {"x": "0100"},
                {"x": "1000"}
            ]
        }
    ]
    return scenarios
if __name__ == "__main__":
    result = stimulus_gen()
    # 将结果转换为 JSON 字符串
    if isinstance(result, list):
        result = json.dumps(result, indent=4)
    elif not isinstance(result, str):
        result = json.dumps(result, indent=4)

    with open("stimulus.json", "w") as f:
        f.write(result)
