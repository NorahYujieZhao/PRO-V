import json

def _to_bit_str(value: int, width: int) -> str:
    return format(value, f'0{width}b')

def _create_input_vector(pattern_pos: int, pattern: str, width: int = 1024) -> str:
    # Create 1024-bit vector with pattern at specified position
    result = ['0'] * width
    for i in range(4):
        result[pattern_pos * 4 + i] = pattern[i]
    return ''.join(result)

def stimulus_gen() -> list[dict]:
    scenarios = [
        {
            'scenario': 'SelectFirstInput',
            'vectors': [{'in': _create_input_vector(0, '1010'), 'sel': _to_bit_str(0, 8)}]
        },
        {
            'scenario': 'SelectLastInput',
            'vectors': [{'in': _create_input_vector(255, '1111'), 'sel': _to_bit_str(255, 8)}]
        },
        {
            'scenario': 'AlternatingBitPattern',
            'vectors': [
                {'in': _create_input_vector(10, '1010'), 'sel': _to_bit_str(10, 8)},
                {'in': _create_input_vector(11, '0101'), 'sel': _to_bit_str(11, 8)}
            ]
        },
        {
            'scenario': 'AllZerosExceptSelected',
            'vectors': [{'in': _create_input_vector(100, '1111'), 'sel': _to_bit_str(100, 8)}]
        },
        {
            'scenario': 'MiddleSelection',
            'vectors': [{'in': _create_input_vector(128, '1100'), 'sel': _to_bit_str(128, 8)}]
        },
        {
            'scenario': 'BoundaryTransition',
            'vectors': [
                {'in': _create_input_vector(127, '1010'), 'sel': _to_bit_str(127, 8)},
                {'in': _create_input_vector(128, '0101'), 'sel': _to_bit_str(128, 8)},
                {'in': _create_input_vector(129, '1100'), 'sel': _to_bit_str(129, 8)}
            ]
        },
        {
            'scenario': 'OneHotPattern',
            'vectors': [
                {'in': _create_input_vector(50, '0001'), 'sel': _to_bit_str(50, 8)},
                {'in': _create_input_vector(51, '0010'), 'sel': _to_bit_str(51, 8)},
                {'in': _create_input_vector(52, '0100'), 'sel': _to_bit_str(52, 8)},
                {'in': _create_input_vector(53, '1000'), 'sel': _to_bit_str(53, 8)}
            ]
        },
        {
            'scenario': 'QuarterBoundaryCheck',
            'vectors': [
                {'in': _create_input_vector(63, '1001'), 'sel': _to_bit_str(63, 8)},
                {'in': _create_input_vector(64, '0110'), 'sel': _to_bit_str(64, 8)},
                {'in': _create_input_vector(127, '1010'), 'sel': _to_bit_str(127, 8)},
                {'in': _create_input_vector(128, '0101'), 'sel': _to_bit_str(128, 8)},
                {'in': _create_input_vector(191, '1100'), 'sel': _to_bit_str(191, 8)},
                {'in': _create_input_vector(192, '0011'), 'sel': _to_bit_str(192, 8)}
            ]
        }
    ]

    stimulus_list = []
    for sc in scenarios:
        stimulus_list.append({
            'scenario': sc['scenario'],
            'input variable': sc['vectors']
        })
    
    return stimulus_list
if __name__ == "__main__":
    result = stimulus_gen()
    # 将结果转换为 JSON 字符串
    if isinstance(result, list):
        result = json.dumps(result, indent=4)
    elif not isinstance(result, str):
        result = json.dumps(result, indent=4)

    with open("stimulus.json", "w") as f:
        f.write(result)
