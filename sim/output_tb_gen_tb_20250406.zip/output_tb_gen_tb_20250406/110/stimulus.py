
import json
import random
def stimulus_gen():
    scenarios = []
    
    # BasicTransparentMode: Toggle d every 2 cycles with ena=1
    d_seq = '110011'
    ena_seq = '1' * 12
    scenarios.append({
        'scenario': 'BasicTransparentMode',
        'input variable': [{
            'd': d_seq * 2,
            'ena': ena_seq,
            'clock cycles': 12
        }]
    })

    # BasicHoldMode: Vary d with ena=0
    d_seq = '101010101010'
    ena_seq = '0' * 12
    scenarios.append({
        'scenario': 'BasicHoldMode',
        'input variable': [{
            'd': d_seq,
            'ena': ena_seq,
            'clock cycles': 12
        }]
    })

    # EnableTransitions: Toggle ena every 3 cycles
    d_seq = '1' * 15
    ena_seq = '111000111000111'
    scenarios.append({
        'scenario': 'EnableTransitions',
        'input variable': [{
            'd': d_seq,
            'ena': ena_seq,
            'clock cycles': 15
        }]
    })

    # DataTransitionsAtEnable: Change d with ena transitions
    d_seq = '1100110011001100'
    ena_seq = '1111000011110000'
    scenarios.append({
        'scenario': 'DataTransitionsAtEnable',
        'input variable': [{
            'd': d_seq,
            'ena': ena_seq,
            'clock cycles': 16
        }]
    })

    # RapidDataToggle: Toggle d every cycle with ena=1
    d_seq = '10' * 10
    ena_seq = '1' * 20
    scenarios.append({
        'scenario': 'RapidDataToggle',
        'input variable': [{
            'd': d_seq,
            'ena': ena_seq,
            'clock cycles': 20
        }]
    })

    # AlternatingEnablePattern: Toggle ena every cycle
    d_seq = '1' * 16
    ena_seq = '1010101010101010'
    scenarios.append({
        'scenario': 'AlternatingEnablePattern',
        'input variable': [{
            'd': d_seq,
            'ena': ena_seq,
            'clock cycles': 16
        }]
    })

    # DataChangeBeforeEnable: Change d before ena transitions
    d_seq = '111000111000111'
    ena_seq = '000111000111000'
    scenarios.append({
        'scenario': 'DataChangeBeforeEnable',
        'input variable': [{
            'd': d_seq,
            'ena': ena_seq,
            'clock cycles': 15
        }]
    })

    # DataChangeAfterEnable: Change d after ena transitions
    d_seq = '000111000111000'
    ena_seq = '111000111000111'
    scenarios.append({
        'scenario': 'DataChangeAfterEnable',
        'input variable': [{
            'd': d_seq,
            'ena': ena_seq,
            'clock cycles': 15
        }]
    })

    # LongHoldPeriod: Extended hold mode
    d_seq = '10101010' * 2 + '1111'
    ena_seq = '0' * 20
    scenarios.append({
        'scenario': 'LongHoldPeriod',
        'input variable': [{
            'd': d_seq,
            'ena': ena_seq,
            'clock cycles': 20
        }]
    })

    # RandomPattern: Pseudo-random patterns
    d_seq = '10110100111001011010101'
    ena_seq = '11010011100101101010100'
    scenarios.append({
        'scenario': 'RandomPattern',
        'input variable': [{
            'd': d_seq,
            'ena': ena_seq,
            'clock cycles': 25
        }]
    })

    return scenarios
if __name__ == "__main__":
    result = stimulus_gen()
    # 将结果转换为 JSON 字符串
    if isinstance(result, list):
        result = json.dumps(result, indent=4)
    elif not isinstance(result, str):
        result = json.dumps(result, indent=4)

    with open("stimulus.json", "w") as f:
        f.write(result)
