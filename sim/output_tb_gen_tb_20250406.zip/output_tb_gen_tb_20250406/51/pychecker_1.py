import json
from typing import Any, Dict, List, Union

from cocotb.binary import BinaryValue


class GoldenDUT:
    def __init__(self):
        # No state variables needed for combinational circuit
        pass

    def load(self, stimulus_dict: Dict[str, any]):
        # Define the lookup table
        lut = {
            0: 0x1232,
            1: 0xAEE0,
            2: 0x27D4,
            3: 0x5A0E,
            4: 0x2066,
            5: 0x64CE,
            6: 0xC526,
            7: 0x2F19,
        }

        stimulus_outputs = []
        for stimulus in stimulus_dict["input variable"]:
            # Convert input 'a' to integer
            a_bv = BinaryValue(value=stimulus["a"], n_bits=3, bigEndian=False)
            a_int = a_bv.integer

            # Look up the corresponding output value
            q_int = lut[a_int]

            # Convert to 16-bit BinaryValue
            q_bv = BinaryValue(value=q_int, n_bits=16, bigEndian=False)

            # Add to outputs
            stimulus_outputs.append({"q": q_bv.binstr})

        output_dict = {
            "scenario": stimulus_dict["scenario"],
            "output variable": stimulus_outputs,
        }

        return output_dict


def check_output(stimulus_list):

    dut = GoldenDUT()
    tb_outputs = []

    for stimulus in stimulus_list:

        tb_outputs.append(dut.load(stimulus))

    return tb_outputs


if __name__ == "__main__":

    with open("stimulus.json", "r") as f:
        stimulus_data = json.load(f)

    if isinstance(stimulus_data, dict):
        stimulus_list = stimulus_data.get("input variable", [])
    else:
        stimulus_list = stimulus_data

    outputs = check_output(stimulus_list)

    print(json.dumps(outputs, indent=2))
