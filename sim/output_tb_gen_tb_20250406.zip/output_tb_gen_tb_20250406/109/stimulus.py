import json
def _generate_bit_pattern(width: int, pattern: str) -> str:
    if pattern == 'zeros':
        return '0' * width
    elif pattern == 'ones':
        return '1' * width
    elif pattern == 'alternating':
        return ''.join(['1' if i % 2 else '0' for i in range(width)])
    elif pattern == 'single':
        result = ['0'] * width
        result[50] = '1'
        return ''.join(result)
    elif pattern == 'left_boundary':
        result = ['0'] * width
        result[99] = '1'
        result[98] = '0'
        return ''.join(result)
    elif pattern == 'right_boundary':
        result = ['0'] * width
        result[1] = '1'
        result[0] = '0'
        return ''.join(result)
    elif pattern == 'wrap_around':
        result = ['0'] * width
        result[99] = '1'
        result[0] = '0'
        return ''.join(result)
    elif pattern == 'random':
        return '10101010' * (width // 8) + '10' * (width % 8 // 2)
    return '0' * width

def stimulus_gen() -> list[dict]:
    width = 100
    scenarios = [
        {
            'scenario': 'AllZeros',
            'pattern': 'zeros'
        },
        {
            'scenario': 'AllOnes',
            'pattern': 'ones'
        },
        {
            'scenario': 'AlternatingBits',
            'pattern': 'alternating'
        },
        {
            'scenario': 'SingleBitHot',
            'pattern': 'single'
        },
        {
            'scenario': 'LeftBoundary',
            'pattern': 'left_boundary'
        },
        {
            'scenario': 'RightBoundary',
            'pattern': 'right_boundary'
        },
        {
            'scenario': 'WrapAround',
            'pattern': 'wrap_around'
        },
        {
            'scenario': 'RandomPattern',
            'pattern': 'random'
        }
    ]
    
    stimulus_list = []
    for sc in scenarios:
        stimulus_list.append({
            'scenario': sc['scenario'],
            'input variable': [{
                'in': _generate_bit_pattern(width, sc['pattern'])
            }]
        })
    
    return stimulus_list
if __name__ == "__main__":
    result = stimulus_gen()
    # 将结果转换为 JSON 字符串
    if isinstance(result, list):
        result = json.dumps(result, indent=4)
    elif not isinstance(result, str):
        result = json.dumps(result, indent=4)

    with open("stimulus.json", "w") as f:
        f.write(result)
