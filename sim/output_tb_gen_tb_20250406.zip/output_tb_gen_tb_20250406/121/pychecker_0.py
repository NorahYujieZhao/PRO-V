
import json
from typing import Dict, List, Union


class GoldenDUT:
    def __init__(self):
        # No state needed for combinational logic
        pass

    def load(self, stimulus_dict: Dict[str, any]):
        outputs = []
        
        for stimulus in stimulus_dict['input variable']:
            # Get 4-bit input as string
            in_bits = stimulus['in']
            
            # Convert to integer
            in_val = int(in_bits, 2)
            
            # Find first 1 from MSB
            if in_val & 0b1000:  # bit 3 is set
                pos = 3
            elif in_val & 0b0100:  # bit 2 is set
                pos = 2
            elif in_val & 0b0010:  # bit 1 is set 
                pos = 1
            elif in_val & 0b0001:  # bit 0 is set
                pos = 0
            else:  # no bits set
                pos = 0
                
            # Convert position to 2-bit binary string
            pos_str = format(pos, '02b')
            
            outputs.append({'pos': pos_str})
            
        return outputs
def check_output(stimulus_list):

    dut = GoldenDUT()
    tb_outputs = []


    for stimulus in stimulus_list:

        tb_outputs.append(dut.load(stimulus))

    return tb_outputs

if __name__ == "__main__":

    with open("stimulus.json", "r") as f:
        stimulus_data = json.load(f)


    if isinstance(stimulus_data, dict):
        stimulus_list = stimulus_data.get("input variable", [])
    else:
        stimulus_list = stimulus_data



    outputs = check_output(stimulus_list)

    print(json.dumps(outputs, indent=2))

