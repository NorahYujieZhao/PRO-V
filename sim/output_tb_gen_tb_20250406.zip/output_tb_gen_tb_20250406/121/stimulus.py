import json
def stimulus_gen() -> list[dict]:
    scenarios = [
        {
            "scenario": "AllZerosInput",
            "input variable": [{"in": "0000"}]
        },
        {
            "scenario": "SingleBitPatterns",
            "input variable": [
                {"in": "0001"},
                {"in": "0010"},
                {"in": "0100"},
                {"in": "1000"}
            ]
        },
        {
            "scenario": "AllOnesInput",
            "input variable": [{"in": "1111"}]
        },
        {
            "scenario": "LeftmostPriority",
            "input variable": [
                {"in": "1100"},
                {"in": "1010"},
                {"in": "1001"}
            ]
        },
        {
            "scenario": "AlternatingBits",
            "input variable": [
                {"in": "1010"},
                {"in": "0101"}
            ]
        },
        {
            "scenario": "RightmostBitSet",
            "input variable": [
                {"in": "0001"},
                {"in": "1001"},
                {"in": "0101"}
            ]
        },
        {
            "scenario": "AdjacentBitsSet",
            "input variable": [
                {"in": "0011"},
                {"in": "0110"},
                {"in": "1100"}
            ]
        },
        {
            "scenario": "RandomPatterns",
            "input variable": [
                {"in": "1011"},
                {"in": "0111"},
                {"in": "1101"}
            ]
        }
    ]
    return scenarios
if __name__ == "__main__":
    result = stimulus_gen()
    # 将结果转换为 JSON 字符串
    if isinstance(result, list):
        result = json.dumps(result, indent=4)
    elif not isinstance(result, str):
        result = json.dumps(result, indent=4)

    with open("stimulus.json", "w") as f:
        f.write(result)
