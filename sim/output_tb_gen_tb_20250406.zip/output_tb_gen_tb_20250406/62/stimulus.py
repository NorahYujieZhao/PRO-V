import json
def _to_bit_str(value: int, width: int = 1) -> str:
    return format(value, f'0{width}b')

def _gen_state_vector(state_num: int) -> str:
    # Generate one-hot encoded state vector
    return _to_bit_str(1 << (9-state_num), width=10)

def stimulus_gen() -> list[dict]:
    stimulus_list = [
        {
            "scenario": "BasicTransitionToS1",
            "input variable": [{
                "in": "1",
                "state": "0000000001"
            }]
        },
        {
            "scenario": "PathToS7",
            "input variable": [{
                "in": "1",
                "state": "0000000001"
            }]
        },
        {
            "scenario": "PathToS8",
            "input variable": [{
                "in": "0",
                "state": _gen_state_vector(5)
            }]
        },
        {
            "scenario": "PathToS9",
            "input variable": [{
                "in": "0",
                "state": _gen_state_vector(6)
            }]
        },
        {
            "scenario": "ReturnToS0FromS7",
            "input variable": [{
                "in": "0",
                "state": _gen_state_vector(7)
            }]
        },
        {
            "scenario": "StayInS7",
            "input variable": [{
                "in": "1",
                "state": _gen_state_vector(7)
            }]
        },
        {
            "scenario": "ReturnToS0FromS8",
            "input variable": [{
                "in": "0",
                "state": _gen_state_vector(8)
            }]
        },
        {
            "scenario": "ReturnToS0FromS9",
            "input variable": [{
                "in": "0",
                "state": _gen_state_vector(9)
            }]
        }
    ]
    return stimulus_list
if __name__ == "__main__":
    result = stimulus_gen()
    # 将结果转换为 JSON 字符串
    if isinstance(result, list):
        result = json.dumps(result, indent=4)
    elif not isinstance(result, str):
        result = json.dumps(result, indent=4)

    with open("stimulus.json", "w") as f:
        f.write(result)
