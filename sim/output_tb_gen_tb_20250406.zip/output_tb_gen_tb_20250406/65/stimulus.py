import json
def _to_bit_str(value: int, width: int = 1) -> str:
    return format(value, f'0{width}b')

def stimulus_gen() -> list[dict]:
    scenarios = [
        {
            "scenario": "AllZeroInputs",
            "input variable": [{
                "a": "0",
                "b": "0",
                "c": "0",
                "d": "0",
                "e": "0"
            }]
        },
        {
            "scenario": "AllOneInputs",
            "input variable": [{
                "a": "1",
                "b": "1",
                "c": "1",
                "d": "1",
                "e": "1"
            }]
        },
        {
            "scenario": "AlternatingPattern",
            "input variable": [{
                "a": "1",
                "b": "0",
                "c": "1",
                "d": "0",
                "e": "1"
            }]
        },
        {
            "scenario": "SingleOneHot",
            "input variable": [{
                "a": "1",
                "b": "0",
                "c": "0",
                "d": "0",
                "e": "0"
            }]
        },
        {
            "scenario": "InvertedOneHot",
            "input variable": [{
                "a": "0",
                "b": "1",
                "c": "1",
                "d": "1",
                "e": "1"
            }]
        },
        {
            "scenario": "TwobitGroups",
            "input variable": [{
                "a": "1",
                "b": "1",
                "c": "0",
                "d": "0",
                "e": "0"
            }]
        },
        {
            "scenario": "ThreeBitGroups",
            "input variable": [{
                "a": "1",
                "b": "1",
                "c": "1",
                "d": "0",
                "e": "0"
            }]
        },
        {
            "scenario": "CheckerboardPattern",
            "input variable": [{
                "a": "1",
                "b": "0",
                "c": "1",
                "d": "0",
                "e": "0"
            }]
        }
    ]
    return scenarios
if __name__ == "__main__":
    result = stimulus_gen()
    # 将结果转换为 JSON 字符串
    if isinstance(result, list):
        result = json.dumps(result, indent=4)
    elif not isinstance(result, str):
        result = json.dumps(result, indent=4)

    with open("stimulus.json", "w") as f:
        f.write(result)
