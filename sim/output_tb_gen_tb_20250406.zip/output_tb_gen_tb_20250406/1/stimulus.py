import json
def _generate_walking_ones(width: int) -> str:
    result = ['0'] * width
    result[0] = '1'
    return ''.join(result)

def _generate_alternating_bits(width: int, start_with_one: bool) -> str:
    pattern = '10' if start_with_one else '01'
    return (pattern * (width // 2 + 1))[:width]

def stimulus_gen() -> list[dict]:
    width = 100
    all_zeros = '0' * width
    all_ones = '1' * width
    alt_pattern1 = _generate_alternating_bits(width, True)
    alt_pattern2 = _generate_alternating_bits(width, False)
    walking_ones = _generate_walking_ones(width)
    
    scenarios = [
        {
            "scenario": "AllZeroSelect0",
            "input variable": [{
                "a": all_zeros,
                "b": all_zeros,
                "sel": "0"
            }]
        },
        {
            "scenario": "AllZeroSelect1",
            "input variable": [{
                "a": all_zeros,
                "b": all_zeros,
                "sel": "1"
            }]
        },
        {
            "scenario": "AllOnesSelect0",
            "input variable": [{
                "a": all_ones,
                "b": all_zeros,
                "sel": "0"
            }]
        },
        {
            "scenario": "AllOnesSelect1",
            "input variable": [{
                "a": all_zeros,
                "b": all_ones,
                "sel": "1"
            }]
        },
        {
            "scenario": "AlternatingBitsSelect0",
            "input variable": [{
                "a": alt_pattern1,
                "b": alt_pattern2,
                "sel": "0"
            }]
        },
        {
            "scenario": "AlternatingBitsSelect1",
            "input variable": [{
                "a": alt_pattern1,
                "b": alt_pattern2,
                "sel": "1"
            }]
        },
        {
            "scenario": "WalkingOnesSelect0",
            "input variable": [{
                "a": walking_ones,
                "b": all_zeros,
                "sel": "0"
            }]
        },
        {
            "scenario": "WalkingOnesSelect1",
            "input variable": [{
                "a": all_zeros,
                "b": walking_ones,
                "sel": "1"
            }]
        }
    ]
    return scenarios
if __name__ == "__main__":
    result = stimulus_gen()
    # 将结果转换为 JSON 字符串
    if isinstance(result, list):
        result = json.dumps(result, indent=4)
    elif not isinstance(result, str):
        result = json.dumps(result, indent=4)

    with open("stimulus.json", "w") as f:
        f.write(result)
