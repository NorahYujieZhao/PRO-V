import json
def _to_bit_str(value: int) -> str:
    return '1' if value else '0'

def stimulus_gen() -> list[dict]:
    scenarios = [
        {
            'scenario': 'AllZeroInputs',
            'vectors': [(0,0,0,0,0,0,0,0,0,0)]
        },
        {
            'scenario': 'AllOneInputs',
            'vectors': [(1,1,1,1,1,1,1,1,1,1)]
        },
        {
            'scenario': 'FirstP1AndGateActive',
            'vectors': [(1,1,1,0,0,0,0,0,0,0)]
        },
        {
            'scenario': 'SecondP1AndGateActive',
            'vectors': [(0,0,0,1,1,1,0,0,0,0)]
        },
        {
            'scenario': 'FirstP2AndGateActive',
            'vectors': [(0,0,0,0,0,0,1,1,0,0)]
        },
        {
            'scenario': 'SecondP2AndGateActive',
            'vectors': [(0,0,0,0,0,0,0,0,1,1)]
        },
        {
            'scenario': 'AlternatingBitsP1',
            'vectors': [(1,0,1,0,1,0,0,0,0,0)]
        },
        {
            'scenario': 'BothOutputsSimultaneous',
            'vectors': [(1,1,1,0,0,0,1,1,0,0)]
        }
    ]
    
    stimulus_list = []
    for sc in scenarios:
        inputs = []
        for vector in sc['vectors']:
            inputs.append({
                'p1a': _to_bit_str(vector[0]),
                'p1b': _to_bit_str(vector[1]),
                'p1c': _to_bit_str(vector[2]),
                'p1d': _to_bit_str(vector[3]),
                'p1e': _to_bit_str(vector[4]),
                'p1f': _to_bit_str(vector[5]),
                'p2a': _to_bit_str(vector[6]),
                'p2b': _to_bit_str(vector[7]),
                'p2c': _to_bit_str(vector[8]),
                'p2d': _to_bit_str(vector[9])
            })
        stimulus_list.append({
            'scenario': sc['scenario'],
            'input variable': inputs
        })
    return stimulus_list
if __name__ == "__main__":
    result = stimulus_gen()
    # 将结果转换为 JSON 字符串
    if isinstance(result, list):
        result = json.dumps(result, indent=4)
    elif not isinstance(result, str):
        result = json.dumps(result, indent=4)

    with open("stimulus.json", "w") as f:
        f.write(result)
